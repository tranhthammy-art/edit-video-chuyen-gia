---
name: edit-video-chuyen-gia
description: Dựng video ngắn TikTok, Facebook Reels từ nguồn và mẫu, với chữ động, cảnh trám, âm thanh và nhịp cảm xúc. Dùng khi người dùng gọi /edit video chuyên gia, edit video chuyên gia hoặc $edit-video-chuyen-gia, hoặc muốn dựng theo quy trình này.
---

# Edit video chuyên gia

Tạo bản video hoàn chỉnh có thể xem/tải. Học ngôn ngữ dựng của mẫu rồi điều chỉnh theo nội dung mới: chữ Việt có thứ bậc, chuyển động theo ý, cảnh trám có liên hệ, nhạc giàu cảm xúc và SFX có chủ đích.

## Bắt đầu

- Nhận `/edit video chuyên gia` là lời gọi skill này trong dự án VAS. Nếu chưa có nguồn, hỏi một lần để người dùng gửi link/file. Có nguồn nhưng thiếu mẫu thì dùng phong cách mặc định và tiến hành.
- Theo AGENTS.md và AGENTS.customs.md. Tạo job bằng `$video-job-manager`, trừ khi ID/path job đang sửa đã có rõ. Chỉ cài dependency công đoạn hiện tại cần.
- Tải bằng skill hiện có phù hợp: `$facebook-reel-downloader`, `$tiktok-downloader`, `$video-downloader`. Nếu nguồn bị chặn/đòi đăng nhập, yêu cầu file nguồn; không tự nhận đã tải hoặc xem/nghe.
- Không mặc định dùng Remotion. Nếu dùng, đọc router chính thức `.agents/skills/remotion-best-practices/SKILL.md`, specialist được chọn và kiểm tra bundle theo AGENTS.md trước khi triển khai.

## Phân tích và lên timeline

Đọc [references/production.md](references/production.md) khi bắt đầu phân tích/dựng. Lập bảng shot/sự kiện gồm thời gian, lời, hình, chữ, animation, SFX, nhạc, chuyển cảnh và tác dụng. Xem dày hơn quanh điểm đổi chữ/cut; không gọi lấy mẫu vài frame là phân tích mọi frame. Phân biệt điều quan sát được, đo được và đề xuất.

Tạo transcript thời gian câu/từ, giữ ASR thô, sửa lỗi khi có căn cứ. Chọn cụm ý để nhấn; không ép mọi từ thành chữ lớn. Khi chưa được yêu cầu cắt nội dung, giữ đầy đủ; có thể xuất thêm bản ngắn và nói rõ phần bị cắt.

## Công thức mặc định có thể điều chỉnh

- Khung dọc 1080×1920; tôn trọng FPS nguồn. Chữ tránh mặt và vùng nút giao diện nền tảng, kiểm tra trên frame thật.
- Be Vietnam Pro Black/SemiBold; trắng ngà, viền mint và glow vừa phải, vàng ấm cho điểm cảm xúc. Line-height ≥1.25, mặc định 1.28. Co cỡ hoặc xuống dòng trước khi tràn.
- Thứ bậc kicker → từ khóa lớn → dòng hỗ trợ. Phóng/nảy nhẹ, trượt, ghép ký tự, giãn chữ, quét sáng: chọn vài họ hiệu ứng theo ý đồ, không đổi vô cớ mỗi từ.
- Mỗi **cụm chữ** mới có SFX ngắn phù hợp; từ khóa có nhấn riêng. Không bíp từng ký tự. Căn theo animation và lời nói.
- Cảnh trám đúng ý, không che mặt/miệng: footage hoặc ảnh lia/zoom chậm, có thể hòa mềm phần trên. Dùng ảnh AI qua công cụ imagegen theo skill, ghi tính minh họa; không mô tả ảnh chuyển động là cảnh phim quay thật.
- Whip mềm, zoom nhấn, light sweep ở chỗ đổi ý/nghỉ câu. Số lượng theo độ dài; tránh rung/flash phá cảm xúc.
- Nội dung tâm lý ưu tiên khoảng thở. Khi quá nhanh, thử 0.88–0.94×, giữ cao độ giọng và giãn đồng bộ hình/chữ/cảnh/SFX; không áp một tốc độ cho mọi thể loại.
- Nhạc cảm xúc: piano thưa nốt 60–72 BPM, hợp âm ngân dài, nền dây/pad ấm nhẹ. Khi yêu cầu đổi nhạc, chọn/phối bản khác; chỉ giảm âm lượng nhạc cũ chưa đủ.

## Dựng, sửa và bàn giao

Đọc [references/technical-recipes.md](references/technical-recipes.md) để dùng tài nguyên, dựng chữ Việt, mix và giảm tốc. Tạo code và timeline mới theo nguồn của job hiện tại; không dùng path hay nội dung từ job cũ.

Đã có master hình và cần giảm tốc/đổi nhạc: dùng `scripts/retime_mix.py --help`. Helper lấy master hình, nguồn giọng, nhạc mới và SFX tùy chọn, giãn đồng bộ và giữ cao độ. Nếu chỉ có bản trộn nhạc, tìm lại source/stem để tránh chồng nhạc cũ/mới.

Giữ phiên bản cũ, kiểm tra still/preview trước render dài, sửa trong cùng job. Giải mã toàn bộ video/audio; kiểm tra kích thước, codec, thời lượng, sync đầu/giữa/cuối, chữ/dấu/clipping và mức âm thanh. Mục tiêu mix tham khảo −16 đến −14 LUFS, true peak ≤−1 dBTP. Nghe nếu công cụ cho phép; nếu chỉ đo, nói đúng giới hạn.

Cập nhật job, nguồn/giấy phép; bàn giao video bằng media embed hoặc link tuyệt đối, bản đầy đủ nếu có, ghi chú ngắn. Không tự đăng mạng xã hội. Tài nguyên trong `assets/`, credit ở [assets/CREDITS.md](assets/CREDITS.md). Nội dung/nhân vật/mốc thời gian ví dụ không tự động dùng lại.
