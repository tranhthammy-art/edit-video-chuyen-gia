# Triển khai

## Dependency và triển khai

Helper `scripts/retime_mix.py` dùng Python standard library và FFmpeg/ffprobe. Nếu tự viết renderer cần Pillow, NumPy hoặc PyAV thì cài đúng gói của công đoạn đó theo Dependency Rule; không mặc định cài Remotion. Đọc asset bằng path resolve và viết nội dung/timeline theo job hiện tại.

## Chữ Việt và hình

Line-height mặc định 1.28, đo rộng cả dòng và co cỡ khi cần. Render từng ký tự phải **cùng baseline**; `anchor='lt'` riêng từng glyph khiến chữ có dấu nhảy lệch ngay cả sau khi đứng yên. Pillow: `baseline = top - font.getbbox(line, anchor='ls')[1]`, rồi `draw.text((x,baseline), char, anchor='ls',...)`. Vị trí ngang theo độ dài prefix có tính kerning. Chừa khoảng cho glow, stroke, dấu khi crop/rotate. Kiểm tra các chuỗi “KIỂM SOÁT”, “RỜI ĐI”, “TIN TƯỞNG” và nội dung thực tế.

Panel trám ví dụ 1080×630, rõ đến y~390 rồi hòa mềm; kiểm tra không chạm mắt/miệng. Zoom ảnh 1.04→1.12 vài giây, lia chậm. Chuyển cảnh khoảng 0.2–0.35s quanh nghỉ câu; điều chỉnh độ mạnh theo cảm xúc. Các giá trị phải thích ứng bố cục nguồn.

## Âm thanh

Tách giọng/nhạc/SFX. SFX theo timeline cụm chữ, ngắn và không chồng dày; từ quan trọng thêm hit nhẹ, transition dùng air sweep. Nhạc dưới lời khoảng 10–16 dB tùy nguồn/cảm nhận. Automation hoặc sidechain attack nhẹ/release chậm, limiter chỉ bắt đỉnh. Đo lại sau encode AAC.

Phối piano từ asset: chuẩn hóa mẫu, repitch từ nốt gần nhất, giữ attack, fade đuôi tránh click; reverb/stereo delay nhẹ. Phong cách cảm xúc 60–72 BPM, 1–2 nốt giai điệu mỗi ô nhịp có nghỉ, hợp âm ngân, pad thấp. Giữ credit theo assets/CREDITS.md.

## Giảm tốc và đổi nhạc từ stem

`python customs/skills/edit-video-chuyen-gia/scripts/retime_mix.py --visual <master.mp4> --voice <source.mp4> --music <new.wav> --sfx <sfx.wav> --speed 0.88 --duration <giây_nguồn> --output <job/output/v3.mp4>`

Visual chỉ lấy hình. Voice phải sạch hoặc chưa chèn nhạc cũ. Music là bản nhạc đã chọn/phối mới, helper không tự sáng tác. SFX cùng timeline nguồn được atempo giữ cao độ. Nhạc mới giữ tốc độ riêng. `--trim` tính theo giây timeline nguồn, output dài trim/speed. Cue đã gắn hình giãn cùng tỷ lệ. Không dùng helper để làm speed ramp không đều.

## QA

Decode: `ffmpeg -v error -i <output> -f null -`. Đo: `ffmpeg -i <output> -af ebur128=peak=true -f null -`. Probe codec/FPS/kích thước/duration. Xem frame đầu/giữa/cuối và vào/giữ/ra của chữ; nghe nếu có thể và nêu giới hạn nếu chỉ đo. Kiểm tra giữ/cắt CTA, credit, tính minh họa AI trước bàn giao.
