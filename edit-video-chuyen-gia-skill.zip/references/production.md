# Phân tích mẫu và biên tập nội dung

Tải nguồn/mẫu riêng trong job và lưu URL, metadata. Lập contact sheet bằng skill sẵn có, xem thêm frame quanh cut, chữ vào/ra và transition. Với yêu cầu từng frame, ghi rõ phạm vi thực sự đã giải mã/kiểm tra; không suy diễn âm thanh từ hình. Chỉ nhận diện nhạc/SFX chính xác khi có căn cứ.

Bảng thời gian: vào–ra | lời | cỡ cảnh/cảnh trám | chữ/thứ bậc | animation vào/giữ/ra | SFX | nhạc/ducking | chuyển cảnh | ý đồ. Ghi màu, stroke/glow, vị trí, fade mask và nhịp cut. Tách kỹ thuật tái sử dụng với nội dung riêng của mẫu.

Mỗi ý cần trả lời người xem nên hiểu/cảm thấy gì. Từ khóa giữ nghĩa, reveal theo phát âm; ví dụ “rời đi” không nên lộ kết luận ngay đầu câu. Cảnh minh họa phải liên quan: áp lực → khoảng cách, không gian → cảnh thoáng, tin tưởng → kết nối; không dùng bộ cảnh này cho mọi chủ đề.

Lưu plan ở `source/creative_plan.toml` hoặc JSON: source, trim, speed, duration, cues, broll, transitions, music, SFX. Cue có start/end và tùy chọn reveal/kicker/title/support/size/animation/color. Với nguồn FPS biến thiên, dùng PTS, không lấy index frame chia FPS đích.

“Quá nhanh, thiếu cảm xúc”: chỉnh nhịp lời/khoảng nghỉ/nhạc trước, không chỉ slow-motion hình. Giảm tốc đồng bộ, giữ cao độ. Nếu chèn nghỉ giữa câu phải dịch mọi cue phía sau và giữ sync miệng, tránh cắt đầu/phụ âm cuối. “Chưa bắt mắt”: kiểm tra thứ bậc và reveal trước khi tăng số hiệu ứng. “Thiếu cảnh trám”: thêm minh họa đúng ý.

Nhạc khác cần thay giai điệu/hòa âm/nhạc cụ/bản thu, không chỉ tempo/volume. Ví dụ V3 có phối piano mới 64 BPM, ít nốt, ngân dài, pad dây, SFX nhẹ hơn. Đây là điểm khởi đầu cho chủ đề tương tự, không phải preset bắt buộc.

