"""Retime a visual master and clean voice, then mix replacement music and SFX."""
import argparse
import json
import math
from pathlib import Path
import shutil
import subprocess


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for flag in ('visual', 'voice', 'music', 'output'):
        p.add_argument('--' + flag, required=True, type=Path)
    p.add_argument('--sfx', type=Path)
    p.add_argument('--speed', type=float, default=.88)
    p.add_argument('--duration', type=float, required=True, help='Source timeline duration, seconds')
    p.add_argument('--trim', type=float, help='Optional end on the source timeline')
    p.add_argument('--fps', type=float, default=25)
    p.add_argument('--music-gain', type=float, default=1.0, help='For an already leveled music stem')
    p.add_argument('--sfx-gain', type=float, default=.72)
    p.add_argument('--ffmpeg', default='ffmpeg')
    a = p.parse_args()
    for value in (a.speed, a.duration, a.fps, a.music_gain, a.sfx_gain):
        if not math.isfinite(value):
            p.error('Parameters must be finite')
    if not .5 <= a.speed <= 2 or a.duration <= 0 or not 1 <= a.fps <= 120:
        p.error('Require speed 0.5..2, positive duration, fps 1..120')
    if a.music_gain < 0 or a.sfx_gain < 0:
        p.error('Gains cannot be negative')
    end = a.duration if a.trim is None else a.trim
    if not math.isfinite(end) or not 0 < end <= a.duration:
        p.error('Trim must lie within the source duration')
    inputs = [a.visual, a.voice, a.music] + ([a.sfx] if a.sfx else [])
    for path in inputs:
        if not path.is_file():
            p.error('Missing input: ' + str(path))
    if a.output.resolve() in [v.resolve() for v in inputs] or a.output.exists():
        p.error('Choose a new output path; inputs and previous versions are preserved')
    executable = shutil.which(a.ffmpeg)
    if not executable:
        p.error('FFmpeg unavailable; install it or provide --ffmpeg <absolute path>')
    length = end / a.speed
    fade = min(.55, length / 4)
    graph = [
        f'[0:v]trim=duration={end},setpts=(PTS-STARTPTS)/{a.speed},fps={a.fps},fade=t=out:st={length-fade}:d={fade}[vout]',
        f'[1:a]atrim=duration={end},asetpts=PTS-STARTPTS,atempo={a.speed},volume=0.84,apad,asplit=2[v][detector]',
        f'[2:a]asetpts=PTS-STARTPTS,volume={a.music_gain},afade=t=in:d={min(.8,length/4)}[m]',
        '[m][detector]sidechaincompress=threshold=0.055:ratio=2:attack=35:release=500[bg]',
    ]
    mix = '[v][bg]'
    if a.sfx:
        graph += [f'[3:a]atrim=duration={end},asetpts=PTS-STARTPTS,atempo={a.speed},volume={a.sfx_gain},apad[s]']
        mix += '[s]'
    graph += [f'{mix}amix=inputs={3 if a.sfx else 2}:duration=longest:normalize=0,alimiter=limit=0.86:level=false:latency=true,afade=t=out:st={length-fade}:d={fade}[aout]']
    cmd = [executable, '-n', '-hide_banner', '-i', str(a.visual), '-i', str(a.voice), '-stream_loop', '-1', '-i', str(a.music)]
    if a.sfx:
        cmd += ['-i', str(a.sfx)]
    cmd += ['-filter_complex', ';'.join(graph), '-map', '[vout]', '-map', '[aout]', '-t', str(length), '-c:v', 'libx264', '-crf', '18', '-preset', 'medium', '-threads', '4', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '256k', '-movflags', '+faststart', str(a.output)]
    a.output.parent.mkdir(parents=True, exist_ok=True)
    log = a.output.with_suffix('.encode.log')
    with log.open('w', encoding='utf-8') as handle:
        subprocess.run(cmd, stdout=handle, stderr=handle, check=True)
    report = {'output': str(a.output.resolve()), 'source_seconds': end, 'speed': a.speed, 'expected_seconds': length, 'music': str(a.music.resolve()), 'note': 'Encoding succeeded; decode, loudness and perceptual QA remain required.'}
    a.output.with_suffix('.mix.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(report, ensure_ascii=True))


if __name__ == '__main__':
    main()
