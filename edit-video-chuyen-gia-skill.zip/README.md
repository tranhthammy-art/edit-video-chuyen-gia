# edit-video-chuyen-gia

Skill VAS dựng video ngắn từ nguồn và video mẫu, với chữ động, cảnh trám, âm thanh và nhịp cảm xúc.

## Cài đặt vào VAS

1. Tải `edit-video-chuyen-gia-skill.zip` từ repo này và giải nén vào `customs/skills/edit-video-chuyen-gia/` của VAS. `SKILL.md`, `references/`, `scripts/`, `assets/` và `agents/` phải nằm cùng thư mục skill.
2. Đọc `SKILL.md`, các tài liệu trong `references/` và `AGENTS.md` của VAS. Chạy `python scripts/vas.py doctor` tại thư mục gốc VAS.
3. Khi có footage, cài FFmpeg/ffprobe và các gói cần cho công đoạn dựng. `scripts/retime_mix.py` chỉ dùng Python standard library và FFmpeg/ffprobe. Nếu xử lý lời nói, dùng công cụ phiên âm cục bộ của VAS khi người dùng yêu cầu.

## ChatGPT trình duyệt

Repo GitHub chỉ chứa skill; nó không tự cấp cho ChatGPT web quyền đọc file máy hoặc chạy VAS. Cầu nối VAS web hiện có dành cho `edit-video-tranh-dang-nhac-trend`, chưa có công cụ MCP để chạy quy trình chuyên gia này. Vì vậy chưa thể hứa chỉ dán một câu lệnh vào bất kỳ chat web nào là dựng được video chuyên gia. Có thể dùng skill trong Codex/agent có quyền truy cập VAS cục bộ; muốn dùng trên ChatGPT web cần bổ sung API/MCP riêng cho quy trình này.

Sau khi cài, chỉ xác nhận skill đã có và chờ người dùng giao nguồn; không tự tải, phiên âm hoặc dựng thử.
