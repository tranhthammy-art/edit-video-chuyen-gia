# Tài nguyên đóng gói

- Be Vietnam Pro Black/SemiBold: SIL Open Font License trong `fonts/OFL.txt`. Nguồn https://github.com/google/fonts/tree/main/ofl/bevietnampro
- `audio/*.ogg`: Kenney Interface Sounds, CC0, giấy phép `audio/Kenney-License.txt`. Nguồn https://kenney.nl/assets/interface-sounds ; tải qua https://github.com/kapishdima/soundcn/tree/main/assets/kenney_interface-sounds
- `audio/piano-*.mp3`: Salamander Grand Piano, Alexander Holm, CC BY 3.0. Mẫu https://github.com/Tonejs/audio/tree/master/salamander ; tác giả/giấy phép https://github.com/sfzinstruments/SalamanderGrandPiano ; https://creativecommons.org/licenses/by/3.0/

Credit dùng cho bản nhạc phối từ các mẫu này:

Piano samples: Salamander Grand Piano by Alexander Holm, licensed under CC BY 3.0. Samples were repitched, arranged and mixed for this video.

Giữ giấy phép khi sao chép/phân phối tài nguyên. Không có cookie, tài khoản hay khóa API trong gói.
